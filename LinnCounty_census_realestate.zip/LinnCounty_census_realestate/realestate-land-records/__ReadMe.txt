�Linn County, Iowa

Linn County makes no warranties, expressed or implied, including without limitation, any warranties of merchantability or fitness for a particular purpose.

In no event shall Linn County be liable for lost profits or any consequential or incidental damages caused by the use of this data.

Questions?  Contact Linn County, Iowa GIS by email at gis@linncounty.org or by phone at 319-892-5250.